function showScreen(id) {
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.remove('active');
  });

  document.getElementById(id).classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function openLetter() {
  document.getElementById('envelope').classList.add('open');
  document.getElementById('letterContent').classList.add('show');
}

function blowCandles() {
  document.querySelectorAll('.flame').forEach(flame => {
    flame.classList.add('off');
  });

  document.getElementById('wishMessage').innerHTML =
    'أمنيتك في طريقها ليكي إن شاء الله! ✨💗';

  confetti();
}

let giftOpened = false;

function openGift() {
  if (giftOpened) return;

  giftOpened = true;

  document.getElementById('giftIcon').textContent = '💝';

  document.getElementById('giftMessage').innerHTML =
    'المفاجأة الحقيقية إنك تستاهلي كل الحب والفرحة في الدنيا! ' +
    'وإن شاء الله السنة دي تكون بداية لأحلى حاجات في حياتك. ' +
    '<br><br>وبلاش غرور بقى بعد الكلام الحلو ده 😂🎀';

  confetti();
}

function confetti() {
  const symbols = ['💗', '🎀', '✨', '💕', '🌸'];

  for (let i = 0; i < 35; i++) {
    const item = document.createElement('div');

    item.className = 'floating-item';
    item.textContent = symbols[
      Math.floor(Math.random() * symbols.length)
    ];

    item.style.left = Math.random() * 100 + 'vw';
    item.style.fontSize = (15 + Math.random() * 20) + 'px';
    item.style.animationDuration = (3 + Math.random() * 3) + 's';

    document.getElementById('decor').appendChild(item);

    setTimeout(() => item.remove(), 6500);
  }
}

// قلوب وزينة بتتحرك باستمرار
setInterval(() => {
  const item = document.createElement('div');
  item.className = 'floating-item';
  item.textContent = Math.random() > 0.5 ? '♡' : '✧';

  item.style.left = Math.random() * 100 + 'vw';
  item.style.animationDuration = '7s';
  item.style.fontSize = '20px';

  document.getElementById('decor').appendChild(item);

  setTimeout(() => item.remove(), 7000);
}, 1300);

// موسيقى إلكترونية أصلية بسيطة
let audioContext = null;
let musicTimer = null;
let musicPlaying = false;
let noteIndex = 0;

const melody = [
  523.25, 659.25, 783.99, 659.25,
  587.33, 698.46, 880, 783.99
];

function playNote() {
  if (!audioContext || !musicPlaying) return;

  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();

  oscillator.type = 'sine';
  oscillator.frequency.value = melody[noteIndex % melody.length];

  gain.gain.setValueAtTime(0.001, audioContext.currentTime);
  gain.gain.linearRampToValueAtTime(0.06, audioContext.currentTime + 0.05);
  gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.35);

  oscillator.connect(gain);
  gain.connect(audioContext.destination);

  oscillator.start();
  oscillator.stop(audioContext.currentTime + 0.4);

  noteIndex++;
}

async function toggleMusic() {
  const button = document.getElementById('musicBtn');

  if (!audioContext) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) {
      button.textContent = 'Music unavailable';
      return;
    }
    audioContext = new AudioContextClass();
  }

  if (audioContext.state === 'suspended') {
    await audioContext.resume();
  }

  musicPlaying = !musicPlaying;

  if (musicPlaying) {
    button.textContent = '♫ Music ON';
    playNote();
    musicTimer = setInterval(playNote, 400);
  } else {
    button.textContent = '♫ Music OFF';
    clearInterval(musicTimer);
  }
}